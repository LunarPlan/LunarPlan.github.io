#include "record.h"
#include "base_learner.h"
#include "linear_learner.h"
#include "poly_learner.h"
#include "conjunctive_learner.h"
using namespace record;

PathTree* GPT;

LearnerNode::LearnerNode() {
	learner = NULL;
	next = NULL;
}
LearnerNode::~LearnerNode() {
	if (learner != NULL)
		delete learner;
}


Context::Context(const char* filename_var, const char* filename_pc, int (*func)(int*), 
		const char* func_name, const char* dataset_fname, int timeout) {
	GPT = new PathTree(filename_pc);
	//read_condition(filename_pc);
	std::ifstream varFile(filename_var);
	varFile >> vnum;
	variables = new std::string[Cv0to4];
	vparray = new VariablePowerArray[Cv0to4];
	variables[0] = '1';
	for (int i = 0; i < Cv0to4; i++) {
		for(int j = 0; j < Nv; j++) {
			vparray[i][j] = 0;
		}
	}
	for (int i = 1; i <= Nv; i++) {
		varFile >> variables[i];
		vparray[i][i-1] = 1;
	}
	varFile.close();
	int index = Nv+1;
	for (int i = 0; i < Nv; i++) {
		for (int j = i; j < Nv; j++) {
			vparray[index][i]++;
			vparray[index][j]++;
			variables[index++] = /*"(" +*/ variables[i+1] + "*" + variables[j+1] /*+ ")"*/;
		}
	}
	for (int i = 0; i < Nv; i++) {
		for (int j = i; j < Nv; j++) {
			for (int k = j; k < Nv; k++) {
				vparray[index][i]++;
				vparray[index][j]++;
				vparray[index][k]++;
				variables[index++] = /*"(" +*/ variables[i+1] + "*" + variables[j+1] 
					+ "*" + variables[k+1] /*+ ")"*/;
			}
		}
	}
	for (int i = 0; i < Nv; i++) {
		for (int j = i; j < Nv; j++) {
			for (int k = j; k < Nv; k++) {
				for (int l = k; l < Nv; l++) {
					vparray[index][i]++;
					vparray[index][j]++;
					vparray[index][k]++;
					vparray[index][l]++;
					variables[index++] = /*"(" +*/ variables[i+1] + "*" + variables[j+1] 
						+ "*" + variables[k+1] + "*" + variables[l+1]/* + ")"*/;
				}
			}
		}
	}

	States* ss = new States[3];
	gsets = &ss[1];
	//std::cout << YELLOW << "$$$$$$$$$$$$$$$$$$$$$$$$<gsets=" << gsets << ">, ss=<" << ss << ">" <<  NORMAL;
	//std::cout << gsets[-1];
	gsets[NEGATIVE].label = NEGATIVE;
	gsets[QUESTION].label = QUESTION;
	gsets[POSITIVE].label = POSITIVE;
	//gsets[CNT_EMPL].label = CNT_EMPL;
	if (dataset_fname != NULL) {
		std::cout << "dataset filename := " << dataset_fname << std::endl;
		std::ifstream fin(dataset_fname);
		if (fin) {
			int l, pn, nn;
			fin >> l >> pn >> nn;
			std::cout << "l:= " << l << "  pn:=" << pn << "  nn:=" << nn << std::endl;
			gsets[POSITIVE].initFromFile(pn, fin);
			gsets[NEGATIVE].initFromFile(nn, fin);
			fin.close();
		}
	}
	first = NULL;
	last = NULL;
	register_program(func, func_name);
	this->timeout = timeout;
	srand(time(NULL)); // initialize seed for rand() function
}

Context::~Context() {
	// clean up heap memory
	LearnerNode* p = first;
	LearnerNode* pp;

	while (p != NULL) {
		pp = p->next;
		delete p;
		p = pp;
	}

	if (gsets) {
		States* ss = &gsets[-1];
		delete []ss;
		ss = NULL;
		gsets = NULL;
	}

	if (variables != NULL) {
		delete []variables;
		variables = NULL;
	}
	if (vparray != NULL) {
		delete vparray;
		vparray = NULL;
	}
}


Context& Context::addLearner(const char* learnerName) {
	BaseLearner* newLearner = NULL;
	if (strcmp(learnerName, "linear") == 0)
		newLearner = new LinearLearner(gsets);
	else if (strcmp(learnerName, "poly") == 0)
		newLearner = new PolyLearner(gsets);
	else if (strcmp(learnerName, "conjunctive") == 0)
		newLearner = new ConjunctiveLearner(gsets);

	if (last == NULL) {
		last = new LearnerNode();
		first = last;
	} else {
		last->next = new LearnerNode();
		last = last->next;
	}
	last->learner = newLearner;
	return *this;
}

int Context::learn(const char* filename_cnt, const char* filename_inv, int times) {
	if (signal(SIGALRM, sig_alrm) == SIG_ERR)
		exit(-1);
	alarm(timeout);

	if (first == NULL) {
		std::cerr << "Leaner has not been assigned. Please add 'learners=***' in your cfg file.\n";
		return 1;
	}

	//*
	for (int iverify = 1; iverify <= Mverify; iverify++) {
#ifdef __PRT
		std::cout << YELLOW << BOLD << ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Iteration" << iverify <<" >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n" << NORMAL;
#endif
		if (filename_cnt) {
			first->learner->runCounterExampleFile(filename_cnt);
		}

		PathTreeNode* pnode = GPT->getNextUncompleteNode(GPT->root);
		//std::cout << "&&&&&&&&&&& root = " << GPT->root->path.toString() << std::endl;
		//std::cout << "&&&&&&&&&&& pnode = " << pnode->path.toString() << std::endl;
		while(pnode != NULL) {
#ifdef __PRT
			std::cout << GREEN << "\n***************Learning PATH@[" << BOLD << pnode->path << NORMAL << GREEN << "] depth = " << BOLD << pnode->path.depth << NORMAL << GREEN << "*************\n" << NORMAL;
#endif
			if (pnode->path.toString() == "*0") {
				std::cout << "Learn on the Post condition path.\n";
				pnode->invariant = "1>0";
				pnode->isDone = true;
				pnode->isChecked = true;
				pnode = GPT->getNextUncompleteNode(GPT->root);
				continue;
			}

			LearnerNode* p = first;
			while (p) {
				pnode->checked_time++;
				if (p->learner->learn(&pnode->path) == 0) {
					pnode->invariant = p->learner->invariant();
					pnode->isDone = true;
					break;
				} else {
					p = p->next;
				}
			}
			pnode->isChecked = true;
			pnode = GPT->getNextUncompleteNode(GPT->root);
		}
		//std::cout << YELLOW << BOLD << "######################################## " << iverify <<" learning>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n" << NORMAL;
		std::cout << GREEN << *GPT << NORMAL; // << std::endl;
		std::cout << YELLOW << BOLD << "  Loop Invariant Candidate: " << GPT->invariant() << NORMAL << std::endl;
		std::ofstream invFile(filename_inv);
		invFile << GPT->invariant();
		invFile.close();
		//std::cout << GREEN << BOLD << "######################################## " << iverify <<" learning<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< \n" << NORMAL;
		//std::cout << GREEN << BOLD << "######################################## " << iverify <<" verification>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> \n" << NORMAL;
		//*/

		if(External::candidateVerify(32) == 0) {
			//std::cout << GREEN << BOLD << "###################################### " << iverify <<" verification YYY<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< \n" << NORMAL;
			//std::cout << GREEN << *GPT << NORMAL << std::endl;
			std::cout << YELLOW << BOLD << "VERIFIED." << NORMAL;
			return 0;
		}
		//std::cout << GREEN << BOLD << "###################################### " << iverify <<" verification NNN<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< \n" << NORMAL;
		GPT->clearDoneMark();
		/*
		if (iverify >= 2) {
			GPT->root->isChecked = true;
			GPT->root->isDone = false;
			std::cout << GREEN << *GPT << NORMAL << std::endl;
		}
		*/
	}
#if 0
	char filename[256]; 
#ifdef __DS_ENABLED
	sprintf(filename, "%s.ds", (char*)filename_inv);
	p->learner->save2file(filename);
#endif
#endif
	return 1;
}

