#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <time.h>
#include "instrumentation.h"
#include <assert.h>
#include "path.h"
#include "color.h"
#include "record.h"
//using namespace record;

bool _passP = false;
bool _passQ = false;

jmp_buf jmpbuffer;

double states[Mstates+1][Nv];
Path path[Mstates+1];
int num_state = -1;

bool drop = false;

void record_path(int depth, int v) {
	/*
	if (num_state >= Mstates) {
		longjmp(jmpbuffer, 0);
		return;
	}
	*/
#ifdef CONSERVATIVE 
	if (drop == true)
		return;
#endif
	//std::cout << "." << v;
	//std::cout << "@" << depth;
	path[num_state].depth = depth + 1;
	if (v == 1)
		path[num_state].set(depth);
	else
		path[num_state].unset(depth);
	//std::cout << "[" << path[num_state][depth] << "] -->" << std::flush;
}

int addStateInt(int first ...)
{
	num_state++;
	/*
#ifdef __PRT_TRACE
	std::cout << "{" << num_state << "}" << std::flush;
#endif
*/
#ifdef AGGRESSIVE
	if (num_state >= Mstates) {
		_passP = false;
		_passQ = true;
		num_state--;
		std::cout << "\n\t" << UNDERLINE << RED << "{drop trace}... long jump begins" << NORMAL << std::flush;
		longjmp(jmpbuffer, 0);
		return 0;
	}
#endif
#ifdef CONSERVATIVE 
	if (num_state >= 0.99 * Mstates) drop = true;
	else if (num_state >= 0.8 * Mstates) {
		drop = rand() / Mstates >= num_state? true : false;
	}
	if (drop == true) {
		num_state--;
		return 0;
	}
#endif
	va_list ap;
	va_start(ap, first);
	states[num_state][0] = first;
	for (int i = 1; i < Nv; i++) {
		states[num_state][i] = va_arg(ap, int);
	}
	va_end(ap);
#if 0
#ifdef __PRT_TRACE
	std::cout << "(" << states[num_state][0];
	for (int i = 1; i < Nv; i++)
		std::cout << "," << states[num_state][i];
	std::cout << ") " << std::flush;
#endif
#endif
	//record_path(0, 1);
	return 0;
}

/*
int addStateDouble(double first, ...)
{
	if (num_state >= 0.99 * Mstates)
		return 0;
	va_list ap;
	va_start(ap, first);
	states[num_state][0] = first;
	for (int i = 1; i < Nv; i++) {
		states[num_state][i] = va_arg(ap, double);
	}
	va_end(ap);

	num_state++;
	record_path(0, 1);
	return 0;
}
*/


int beforeLoop()
{
	//std::cout << "---> before_loop";
	for (int i=0; i<num_state; i++)
		path[i].u = 0;
	num_state = -1;
	_passP = false;
	_passQ = false;
	drop = false;
	//record_path(0, 1);
	//std::cout << "[done]";
	return 0;
}


int afterLoop(States* gsets)
{
	//std::cout << GREEN << BOLD << "After Loop.....\n" << NORMAL;
	num_state++;
	int label = 0;
	if (_passP && _passQ) {
		label = POSITIVE;
	} else if (!_passP && !_passQ) {
		label = NEGATIVE; 
	} else if (!_passP && _passQ) {
		label = QUESTION; 
		/*
#ifdef __QUESTION_AS_POSITIVE
		//std::cout << "?->+ ";
		label = POSITIVE; 
#elif __QUESTION_AS_NEGATIVE
		//std::cout << "?->- ";
		label = NEGATIVE;
#else
		//std::cout << "?->? ";
		label = QUESTION; 
#endif
*/
	} else if (_passP && !_passQ) {
		label = CNT_EMPL;
		std::cout << RED << "\ncounter-example trace:  ";
		for (int i = 0; i < num_state; i++) {
			std::cout << "(" << states[i][0];
			for (int j = 1; j < Nv; j++)
				std::cout << "," << states[i][j];
			std::cout << ")->";
		}
		std::cout << "END[x]" << NORMAL << std::endl;
	}

	/*
	switch (label) {
		case POSITIVE:
			std::cout << GREEN;
			break;
		case NEGATIVE:
			std::cout << RED;
			break;
		case QUESTION:
			std::cout << BLUE;
			break;
	}
	*/
	/*
	for (int i = 0; i < num_state; i++) {
		std::cout << CYAN << "[" << path[i] << "] ->" << NORMAL;
	}
	std::cout << std::endl;
	*/
#ifdef __PRT_TRACE
	std::cout << BOLD << BLUE << "\n  $|" << NORMAL;
	for (int i = 0; i < num_state; i++) {
		//std::cout << "--><" << i << "> S(";
		std::cout << "-> " << i << "(";
		for (int j = 0; j < Nv-1; j++)
			std::cout << states[i][j] << ", ";
		std::cout << states[i][Nv-1] << ")";
		std::cout << CYAN << "[" << path[i] << "]" << NORMAL;
	}
	std::cout << NORMAL << "  L[" << labelString(label) << "]" << NORMAL; // << std::endl;
#endif

	//std::cout << "----> add-states to gsets[" << label << "]" << std::endl;
	if (label == POSITIVE || label == NEGATIVE) {
		gsets[label].addStates(states, path, num_state);
	//if (label == POSITIVE || label == NEGATIVE) {
		for(int i = 0; i < num_state; i++)
			GPT->addPath(path[i], label);
		//std::cout << "\n=======================Path Tree====================\n" << *GPT << std::endl;
		//std::cout << "\n=======================Path Tree====================\n" << *GPT << std::endl;
		//std::cout << "states: #(positive0=" << gsets[POSITIVE].size << " #(negative)=" << gsets[NEGATIVE].size << std::endl;
		return label;
	} 
	
	if (label == QUESTION) {
		int beginPositive = num_state;
		for (int i = 0; i < num_state; i++) {
			if(check_precondition(states[i])) {
				beginPositive = i;
				break;
			}
		}
#ifdef __PRT_TRACE
		std::cout << RED << BOLD << "\n!!!find the positive state @" << beginPositive << std::endl << NORMAL;
#endif
#ifdef __QUESTION_AS_POSITIVE
#ifdef __PRT_TRACE
		std::cout << "?->+ ";
#endif
		gsets[POSITIVE].addStates(states, path, beginPositive);
		label = POSITIVE; 
#elif __QUESTION_AS_NEGATIVE
#ifdef __PRT_TRACE
		std::cout << "?->- ";
#endif
		gsets[NEGATIVE].addStates(states, path, beginPositive);
		label = NEGATIVE;
#else
#ifdef __PRT_TRACE
		std::cout << "?->? ";
#endif
		gsets[QUESTION].addStates(states, path, beginPositive);
		label = QUESTION; 
#endif
		gsets[POSITIVE].addStates(&states[beginPositive], &path[beginPositive], num_state - beginPositive);
		for(int i = 0; i < beginPositive; i++)
			GPT->addPath(path[i], label);
		for(int i = beginPositive; i < num_state; i++)
			GPT->addPath(path[i], POSITIVE);
	}
	//std::cout << "\n" << YELLOW << "TREE-ROOT\n" << RED << *GPT << NORMAL << std::endl;
	//std::cout << "<---- add-states to gsets[" << label << "]" << std::endl;
	return label;
}

void printRunResult(int rr) {
	std::cout << labelString(rr);
	return;
}

/*
int mDouble(double* p)
{
	int a[Nv];
	for (int i = 0; i < Nv; i++)
		a[i] = static_cast<int>(p[i]);
	return mInt(a);
}
*/

int mInt(int* p) { return target_program(p); }
