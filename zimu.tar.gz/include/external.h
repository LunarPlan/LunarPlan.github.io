/** @file iif_learn.h
 *  @brief Provide base class for all iif learning algorithms.
 *
 *  This file contains the necessary function support for iif learning algorithms.
 *  The function run_target is the most important function in this base class for now. 
 *
 *  @author Li Jiaying
 *  @bug no known bugs found.
 */
#ifndef _EXTERNAL_
#define _EXTERNAL_

#include "config.h"
#include "states.h"
#include "polynomial.h"
#include "classifier.h"
#include "instrumentation.h"
#include "color.h"

#include <iostream>
#include <iomanip>
#include <float.h>
#include <string.h>
#include <sstream>
#include <assert.h>
#include <sys/time.h>
#include <unistd.h>

class External{
	public:
		static int selectiveSampling(Path* p, std::string candidate, int num, Solution* sols) {
			//std::cout << "------>start externalSelectiveSampling...\n";
			std::cout << GREEN << "[path@" << *p  << " Depth=" << p->depth << " INV:" << candidate << "]" << NORMAL;
#ifdef __PRT_TESTCASE
			std::cout << GREEN << "[path@" << *p  << " Depth=" << p->depth << " INV:" << candidate << "]" << NORMAL;
#endif
			std::ofstream ofs(ProjectHome"/include/reverse_execution/candidate.h");
			ofs << "#ifdef Candidate\n"
				<< "#undef Candidate\n"
				<< "#undef SearchDepth\n"
				<< "#undef Mask\n"
				<< "#endif\n"
				<< "#define Candidate " << candidate << "\n"
				<< "#define SearchDepth " << p->depth <<"\n"
				<< "#define Mask " << p->u << "\n";
			ofs.close();
			std::ostringstream stm;
			stm << ProjectHome"/scripts/ssampling.sh " << Project << " " << num << std::flush;
			//std::cout << RED << "[ExternalCallAs:]" << NORMAL << ProjectHome"/scripts/ssampling.sh " << Project << " " << num;
			//system("cd "ProjectHome);
			
			if (system(stm.str().c_str()) != 0) {
				std::cerr << "Error occured in script/ssampling.sh\n";
				exit(1);
			}
			std::ifstream ifs(ProjectHome"/tmp/"Project".cnt");
			int i = 0;
			while (ifs.good() && i < num) {
				for (int j = 0; j < Nv; j++) {
					ifs >> sols[i][j];
				}
				i++;
			}
			int ret = i;
			ifs.close();

#if 0	
			std::cout << "\n" << BLUE << "RETURN SAMPLES FROM SSAMPLING>>> " << ret << "\n";
			for (int i=0; i<ret; i++) {
				std::cout << "(";
				for (int j = 0; j < Nv-1; j++) {
					std::cout << sols[i][j] << ",";
				}
				std::cout << sols[i][Nv-1] << ") ";
			}
			std::cout << "\n" << NORMAL;
#endif
			
			//std::cout << "<------return from externalSelectiveSampling...\n";
			return ret;
		}

		static int candidateVerify(int cnt_num = 8) {
			std::ostringstream stm;
			stm << ProjectHome"/scripts/verify.sh " << Project << " " << cnt_num;
			int ret = system(stm.str().c_str());
			if (ret != 0) {	
				std::cerr << RED << BOLD << "Candidate can not be verified.\n" << NORMAL;
			}
			return ret;
		}
};

#endif
