/***************************************************************
 *  @file include/branch.h
 *  @brief           
 *             
 *  @author Li Jiaying
 *  @bug no known bugs
 ***************************************************************/
#ifndef _PATH_TREE_H_ 
#define _PATH_TREE_H_
#include "config.h"
#include "color.h"
#include "path.h"
#include <queue>
#include <sstream>
#include <map>
#include <iostream>
//using namespace std;

static std::map<int, std::string> read_condition(const char* ifile) {
	std::map<int, std::string> pc;
	std::ifstream pathfile(ifile);

	std::cout << "pc file@ " << ifile << std::endl;
	int i = 0;
	while (!pathfile.eof()) {
		int no;
		std::string condition;
		pathfile >> no >> condition;
		if (pathfile.eof())
			break;
		pc[no] = condition;
		//pathfile >> pc[i].begin() >> pc[i].end();
		std::cout << " " << i << ">path-condition[*" << no << "] := {" << condition << "}" << std::endl;
		//std::cout << "   |--->path-condition---" << no << "------>" << pc[no] << std::endl;
		i++;
	}
	pc[-1] = "0>-1";
	pc[-2] = "0>-2";

	pathfile.close();
	return pc;
}

//std::map<int, std::string> pc = read_condition(ifile);


class PathTreeNode{
	public:
		PathTreeNode() {
			pnode = NULL;
			tnode = NULL;
			fnode = NULL;
			num_state = 0;
			positive_state = 0;
			negative_state = 0;
			isTrue = true;
			isChecked = false;
			isDone = false;
			checked_time = 0;
			path = "";
			invariant = "";
			condition = "";
		}

		void clear() {
			if (tnode) tnode->clear();
			if (fnode) fnode->clear();
			delete this;
		}

		void reset() {
			isChecked = false;
			isDone = false;
			if (tnode) tnode->reset();
			if (fnode) fnode->reset();
		}

		void clearDoneMark() {
			if (isDone) {
				isDone = false;
				//isChecked = false;
			} else {
				if (tnode) tnode->clearDoneMark();
				if (fnode) fnode->clearDoneMark();
			}
		}

		PathTreeNode* pnode;	
		PathTreeNode* tnode;	
		PathTreeNode* fnode;	
		Path path;
		int num_state;
		int positive_state;
		int negative_state;
		std::string invariant;
		std::string condition;
		bool isTrue;
		bool isChecked;
		bool isDone;
		int checked_time;
		//bool isVerified;
};

class PathTree{
	public:
		PathTreeNode* root;
		std::map<int, std::string> pc;// = read_condition(ifile);
		//PC pc[32];// = read_condition(ifile);

		PathTree(const char* ifile) {
			pc = read_condition(ifile);
			root = new PathTreeNode();
			//root->path = std::string("1");
			//root->path.condition = pc[root->path.toInt()];
			root->path = std::string("*");
			root->path.condition = "0>=0";
			//root->isTrue = true;
			root->isChecked = false;
			//std::cout << "[root] > " << root->path << std::endl; 
			//read_condition(ifile, pc);
			
			PathTreeNode* t = new PathTreeNode();
			root->tnode = t;
			t->pnode = root;
			t->num_state = 0;
			t->isTrue = true;
			t->path = root->path.toString() + "1";
			t->path.condition = pc[t->path.toInt()];
			//std::cout << RED << "++++" << t->path.toString() << "-->" << t->path.condition << std::endl << NORMAL;
			//std::cout << "[root>true] > " << t->path << std::endl; 

			PathTreeNode* f = new PathTreeNode();
			root->fnode = f;
			f->pnode = root;
			f->num_state = 0;
			f->isTrue = false;
			f->path = root->path.toString() + "0";
			f->path.condition = pc[f->path.toInt()];
			//std::cout << RED << "++++" << f->path.toString() << "-->" << f->path.condition << std::endl << NORMAL;
			//std::cout << "[root>false] > " << f->path << std::endl; 
		}

		~PathTree() {
			root->clear();
		}

		PathTreeNode* getNextUncompleteNode(PathTreeNode* node) {
#ifdef _ZERO_CUT_
			if (node->isDone) return NULL;
			return node;
#endif
#ifdef _BEST_CUT_
			if (node->isDone) return NULL;
			if (node->isChecked == false) return node;
			if (node->checked_time <= 2 + node->path.depth && node->checked_time <= 8) return node;
			if (node->tnode == NULL && node->fnode == NULL && node->checked_time <= 8) return node;
#endif
#ifdef _FULL_CUT_
			if (node->isDone) return NULL;
			if (node->tnode == NULL && node->fnode == NULL) return node;
#endif
			PathTreeNode* ret;
			if (node->tnode) {
				ret = getNextUncompleteNode(node->tnode);
				if (ret != NULL) 
					return ret;
			}
			if (node->fnode) {
				ret = getNextUncompleteNode(node->fnode);
				if (ret != NULL) 
					return ret;
			}
			return NULL;
		}

		void reset() {
			root->reset();
		}

		void clearDoneMark() {
			root->clearDoneMark();
		}

		bool addPath(Path& p, int label = 1) {
			//std::cout << "\n" << *this << std::endl;
			//std::cout << "+path@" << p << " " << std::flush;
			PathTreeNode* node = root;
			root->num_state++;
			if (label == 1) root->positive_state++;
			else if (label == -1) root->negative_state++;
			int level = p.depth;
			for (int i = 0; i < level; i++) {
				if (p[i] == 1) {
					if (node->tnode == NULL) {
						PathTreeNode* t = new PathTreeNode();
						node->tnode = t;
						t->pnode = node;
						t->num_state = 0;
						t->isTrue = true;
						t->path = node->path.toString() + "1";
						t->path.condition = pc[t->path.toInt()];
						std::cout << RED << "++++" << t->path.toString() << "-->" << t->path.condition << std::endl << NORMAL;
					}
					node = node->tnode;
				} else if (p[i] == 0) {
					if (node->fnode == NULL) {
						PathTreeNode* f = new PathTreeNode();
						node->fnode = f;
						f->pnode = node;
						f->num_state = 0;
						f->isTrue = false;
						f->path = node->path.toString() + "0";
						f->path.condition = pc[f->path.toInt()];
						std::cout << RED << "++++" << f->path.toString() << "-->" << f->path.condition << std::endl << NORMAL;
					}
					node = node->fnode;
				}
				node->num_state++;
				if (label == 1) node->positive_state++;
				else if (label == -1) node->negative_state++;
			}
			//std::cout << "\n$" << *this << std::endl;
			return true;
		}

		void print(PathTreeNode* ptn, int level = 0) const {
			if (ptn == NULL) return;
			std::cout << BLUE << "   ";
			for(int i = 1; i <= level; i++)
				std::cout << "|\t  ";
			/*
			if (ptn->isTrue)
				std::cout << "|T -->" << YELLOW << ptn->path.toString() << BLUE << "<" << ptn->num_state << ">";
			else
				std::cout << "|F -->" << YELLOW << ptn->path.toString() << BLUE << "<" << ptn->num_state << ">";
				*/
			if (ptn->isTrue)
				std::cout << "|" << CHECKMARK << " ->" << YELLOW << ptn->path.toString() << BLUE << "<s:" << ptn->num_state << " p:" << ptn->positive_state << " n:" << ptn->negative_state << ">";
			else
				std::cout << "|" << CROSSMARK << " ->" << YELLOW << ptn->path.toString() << BLUE << "<s:" << ptn->num_state << " p:" << ptn->positive_state << " n:" << ptn->negative_state << ">";
			//std::cout << "|F--->" << ptn->path.toString() << "<" << ptn->num_state << ">";
			//int path_no = ptn->path.toInt();
			//std::string path_condition = pc[path_no];
			std::cout << CYAN << " $pc: [" << MAGENTA << BOLD << ptn->path.condition << NORMAL << CYAN << "]";
			if (ptn->isChecked)
				std::cout << BOLD << GREEN << " Checked" << YELLOW << ptn->checked_time << NORMAL << BLUE;
			else
				std::cout << BOLD << RED << " Uncheck" << NORMAL << BLUE;
			if (ptn->isDone)
				std::cout << " (DONE)....." << CYAN << "$inv: [" << MAGENTA << BOLD << ptn->invariant << NORMAL << CYAN << "]\n";
			else
				std::cout << " (UNDONE)\n";
			print(ptn->tnode, level+1);
			print(ptn->fnode, level+1);
			return;
		}

		friend std::ostream& operator<< (std::ostream& out, const PathTree& pt) {
			pt.print(pt.root);
			return out;
		}

		std::string invariant() {
			std::queue<PathTreeNode*> nodeQ;
			nodeQ.push(root);
			bool firstElement = true;
			std::ostringstream stm;
			//stm << "0 ";
			while(!nodeQ.empty()) {
				PathTreeNode* p = nodeQ.front();
				nodeQ.pop();
				p->condition = p->path.condition;
				//p->condition = pc[p->path.toInt()];

				if (p->isDone) {
					if (firstElement) {
						//stm << "(" << p->invariant << ") ";
						stm << "( (" << p->condition << ") && (" << p->invariant << ") ) ";
						firstElement = false;
					} else {
						//stm << "|| (" << p->invariant << ") ";
						stm << "|| ( (" << p->condition << ") && (" << p->invariant << ") ) ";
					}
				} else {
					if (p->tnode)
						nodeQ.push(p->tnode);
					if (p->fnode)
						nodeQ.push(p->fnode);
				}
			}
			return stm.str();
		}

};

#endif
