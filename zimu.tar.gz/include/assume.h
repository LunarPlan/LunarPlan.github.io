#ifndef _ASSUME_H_
#define _ASSUME_H_
#define assume(expr) if(expr) {\
		record_path(depth, 1);\
	} else {\
		record_path(depth, 0);\
	} if(expr)

#define Depth(n) do {\
		depth = n;\
	} while(0)

#endif
