/** @file iif_learn.h
 *  @brief Provide base class for all iif learning algorithms.
 *
 *  This file contains the necessary function support for iif learning algorithms.
 *  The function run_target is the most important function in this base class for now. 
 *
 *  @author Li Jiaying
 *  @bug no known bugs found.
 */
#ifndef _LEARNER_BASE_
#define _LEARNER_BASE_

#include "config.h"
#include "states.h"
#include "polynomial.h"
#include "classifier.h"
#include "path.h"
#include "path_tree.h"
#include "instrumentation.h"
#include "color.h"
#include "external.h"

#include <iostream>
#include <iomanip>
#include <float.h>
#include <string.h>
#include <sstream>
#include <assert.h>
#include <sys/time.h>
#include <unistd.h>

#ifdef __PRT_STATISTICS
extern int random_samples, selective_samples;
#endif

static void print(Solution& s, int ret) {
	switch (ret) {
		case -1:
			std::cout << RED;
			break;
		case 0:
			std::cout << BLUE;
			break;
		case 1:
			std::cout << GREEN;
			break;
		default:
			std::cout << YELLOW << BOLD;
			break;
	}
	std::cout << s << " " << NORMAL;
}

class BaseLearner{
	public:
		BaseLearner(States* gsets, /*const char* cntempl_fname = NULL,*/ int (*func)(int*) = target_program):
			gsets(gsets), func(func) { }

		virtual ~BaseLearner() {} 

		void runCounterExampleFile(const char* cntempl_fname = NULL) {
			std::cout.unsetf(std::ios::fixed);
			if (cntempl_fname!= NULL) {
				std::ifstream fin(cntempl_fname);
				std::cout << RED << "Running Counter-Examples from file[" << cntempl_fname << "]\n" << NORMAL;
				if (fin) {
					Solution s;
					while (fin >> s) {
#ifdef __PRT_TESTCASE
						std::cout << BLUE << "  |---> " ;
						std::cout << " ->> " << NORMAL;
#endif
						int ret = runTarget(s);
						print(s, ret);
						//runTarget(s);
						//std::cout << ret << " " << std::flush;
#ifdef __PRT_TRACE
						std::cout << "\n";
#endif
					}
					std::cout << YELLOW << "old scope:=[" << minv << "," << maxv << "]" << NORMAL << std::endl;
					int newscope = maxv;
					for (int i = 0; i < Nv; i++) {
						//while(std::abs(s[i]) > newscope) {
						if (std::abs(s[i]) > newscope) {
							if (newscope * 2 >= 0)
								newscope *= 2;
							else 
								break;
						}
					}
					if (newscope > maxv) {
						maxv = newscope;
						minv = -1 * maxv;
#ifdef __PRT
						std::cout << YELLOW << "new scope:=[" << minv << "," << maxv << "]" << NORMAL << std::endl;
#endif
					}
					fin.close();
					}
				}
			}

			virtual int save2file(const char*) = 0;
			/** @brief This function runs the target_program with the given input
			 *
			 *  @param  input defines input values which are used to call target_program 
			 */
			int runTarget(Solution& input) {
				assert(func != NULL || "Func equals NULL, ERROR!\n");
				beforeLoop();

				//< convert the given input with double type to the input with int type 
				int a[Nv];
				for (int i = 0; i < Nv; i++)
					a[i] = static_cast<int>(input[i]);
				//target_program
				//std::cout << "\n----> run the loop function.\n";
				func(a);
#ifdef AGGRESSIVE
				if (setjmp(jmpbuffer) != 0) {
					std::cout << "SetJump.\n";
					std::cout << "Trigger the drop action, due to too long the trace.\n";
				}
#endif
				//std::cout << "\n<---- run the loop function.\n";

				int label = afterLoop(gsets);
				//std::cout << YELLOW << "\n<<<after afterLoop function. ret = " << label << "\n" << NORMAL;
				if (label == CNT_EMPL) {
					std::cout << RED << BOLD << " \nBUG! Program encountered a Counter-Example trace." << std::endl;
					exit(-2);
				}
				//std::cout << "here105.\n";
				return label;
			}

			/** @brief This method is the entrance for the whole learning procedure.
			 *		   Child class should implement it based on learning algorithm.
			 */
			virtual int learn(Path* path = NULL) = 0;

			/** @brief This method is used to generate new input and drive the testing process.
			 *		   This method is actually does several jobs, depend on parameters. 
			 *		   It is better to split it into several methods.
			 *
			 *		   You can find details of each parameters in child class.
			 */
			int sampling(int randn, int exen, Classifier* cl, Path* path) {
#ifdef __PRT
				std::cout << "{" << GREEN;
#endif
#ifdef __PRT_TESTCASE
				std::cout << "\n" << GREEN;
#endif

#ifndef __SELECTIVE_SAMPLING_ENABLED
				std::cout << "Pure Random";
				randn += exen;
				exen = 0;
#endif
				/*if (path == NULL) std::cout << "path is null\n";
				else std::cout << "path=" << path->toString() << "\n";
				*/
				std::cout << BLUE << "# samples [R: " << randn << ", S: " << randn << "]" <<  std::endl;
				std::cout << BLUE << " >random samples: "<< std::flush;
				Solution input;
				int ret = 0;
				for (int i = 0; i < randn; i++) {
					Classifier::solver(NULL, input);
#ifdef __PRT_STATISTICS
					random_samples++;
#endif
#ifdef __PRT
#ifdef __PRT_TRACE
					//std::cout << "\n";
					//std::cout << "-------> R Testing on input: " << input << std::endl;
#endif
					//std::cout << input; // << " ";
					//std::cout << input << std::flush; // << " ";
#endif
					ret = runTarget(input);
					//std::cout << ret << " " << std::flush;
					print(input, ret);
					/*
					   if (setjmp(jmpbuffer) != 0) {
					   std::cout << "SetJump.\n";
					   std::cout << "Trigger the drop action, due to too long the trace.\n";
					   }
					   */
#ifdef __PRT_TRACE
					//std::cout << RED << "<------- R Testing Done: " << ret << std::endl << NORMAL;
					/*std::cout << input << endl;
					  printRunResult(ret);
					  std::cout << "|";
					  */
#endif
				}

				std::cout << BLUE << "\n >selective samples: "<< std::flush;
				//std::cout << BLUE << "# selective samples: " << exen << std::endl;
				Solution* sols = new Solution[exen];
				//std::cout << BLUE << "classifier: " << cl->toString() << std::endl;
				//int num = External::selectiveSampling(path, cl->toString(), exen, sols);
				for (int i = 0; i < exen; i++) {
					Classifier::solver(cl, sols[i]);
					//std::cout << "[" << sols[i] << "]->";
					sols[i].Integerize();
					//std::cout << "[" << sols[i] << "] \n";
				}
				int num = exen;
				//int num = externalSelectiveSampling(0, cl->toString(), exen, sols);
				//std::cout << YELLOW << "back to selective sampling function.\n";
				//std::cout << BLUE << "!!Actually get #" << num << " samples: ";
#ifdef __PRT_TESTCASE
				std::cout << BLUE << "get #" << num << " samples: ";
				for (int i = 0; i < num; i++) {
					std::cout << "[" << sols[i] << "] ";
				}
				std::cout << std::endl;
#endif
#ifdef __PRT
				std::cout << BLUE;
#endif

				for (int i = 0; i < num; i++) {
#ifdef __PRT_STATISTICS
					selective_samples++;
#endif
#ifdef __PRT_TRACE
					//std::cout << "\n";
					//std::cout << "-------> S Testing on input: " << sols[i]<< std::endl;
#endif
#ifdef __PRT
					//std::cout << sols[i] << std::flush; // << " ";
#endif
					ret = runTarget(sols[i]);
					//std::cout << ret << " " << std::flush;
					print(sols[i], ret);
					//std::cout << RED << "<------- S Testing Done: " << ret << std::endl << NORMAL;
#ifdef __PRT_TRACE
					//std::cout << RED << "<------- S Testing Done: " << ret << std::endl << NORMAL;
					/*std::cout << "|" << input;
					  printRunResult(ret);
					  */
#endif
				}
#ifdef __PRT_TRACE
				std::cout << "\n";
				//std::cout << "RRRR \n";
#endif

#ifdef __PRT
				std::cout << NORMAL << "}" << std::endl;
#endif
				//std::cout << "\nBRANCH INFO\n" << YELLOW << "TREE-ROOT\n" << RED << *GPT << NORMAL << std::endl;
				delete []sols;
				std::cout << "==========================================Path Tree=======================================\n" << *GPT;
				std::cout << NORMAL << "==========================================================================================\n";
				//std::cout << "states: #(positive0=" << gsets[POSITIVE].size << " #(negative)=" << gsets[NEGATIVE].size << std::endl;
				return randn + exen;
			}

			/** @brief This method try to return a readable string which describe the generated invariant.
			 *		   The returned method is also required to be a valid expression which can be used in C program,
			 *		   because we will directly insert the string to the program to be verified.
			 */
			virtual std::string invariant() = 0;

			void printStatistics() {
#ifdef __PRT_STATISTICS
				//std::cout << GREEN << BOLD << "***********************STATISTICS*********************\n";
				//std::cout << GREEN << BOLD << "|*\t\t   " << RED << "random_samples= " << random_samples << "\n";
				//std::cout << GREEN << BOLD << "|*\t\t   " << RED << "selective_samples= " << selective_samples << "\n";
				//std::cout << GREEN << BOLD << "******************************************************\n" << NORMAL;
				std::ofstream of1("../tmp/statistics", std::ofstream::app);
				struct timeval tv;
				gettimeofday(&tv, NULL);
				//time_t nowtime = tv.tv_sec;
				struct tm* nowtm = localtime(&tv.tv_sec);
				char tmbuf[64], buf[64];
				//strftime(tmbuf, sizeof(tmbuf), "%Y-%m-%d %H:%M:%S", nowtm);
				strftime(tmbuf, sizeof(tmbuf), "%H:%M:%S", nowtm);
				snprintf(buf, sizeof(buf), "%s.%06ld", tmbuf, tv.tv_usec);
				//of1 << buf << "\t\t" << random_samples << "\t\t" << selective_samples << std::endl;
				of1 << "\t\t#r_samples=" << random_samples << "\t\t#s_samples=" << selective_samples << std::endl;
				of1.close();
#endif
			}

			protected:
			States* gsets;
			int (*func)(int*);
		};


#endif
