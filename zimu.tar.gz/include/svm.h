#ifndef _SVM_H_
#define _SVM_H_
#include "ml_algo.h"
#include "svm_core.h"
#include "string.h"


class SVM : public MLalgo
{
	public:
		svm_parameter param;
		svm_problem problem;
		int max_size;

		MState* mapped_data;
		int* mapped_label;
		Path* mapped_path;
		double** data; // [max_items * 2];
		double* label; // [max_items * 2];
		int size;
		int etimes;
		int kernel;

		svm_model* model;

	protected:
		int resize(int new_size) {
			//std::cout << "resizing need " << new_size << "... from " << max_size;
			if (new_size <= max_size) return 0;
			assert (new_size > max_size);
			int valid_size = problem.l;

			// enlarge max_size exponentially to cover all the data.
			while (new_size >= max_size) max_size *= 2;
			//std::cout << " ---> " << max_size << "\n";

			MState * new_mapped_data = new MState[max_size];
			memmove(new_mapped_data, mapped_data, valid_size * sizeof(MState*));
			delete[] mapped_data;
			mapped_data = new_mapped_data;

			//double ** new_data = new double*[max_size];
			//memmove(new_data, data, valid_size * sizeof(double**));
			delete[] data;
			//data = new_data;
			data = new double*[max_size];
			for (int i = 0; i < valid_size; i++)
				data[i] = mapped_data[i];

			double* new_label = new double[max_size];
			memmove(new_label, label, valid_size * sizeof(double*));
			delete[] label;
			label = new_label;
			//label = new double[max_size];

			problem.x = (svm_node**)(data);
			problem.y = label;

			//std::cout << "resize done...\n";
			return 0;
		}


	public:
#ifdef __TRAINSET_SIZE_RESTRICTED
		SVM(int type = 0, void (*f) (const char*) = NULL, int size = 2 * restricted_trainset_size+1) : max_size(size) {
#else
			SVM(int type = 0, void (*f) (const char*) = NULL, int size = 1000000) : max_size(size) {
#endif
				prepare_svm_parameters(&param, type);
				if (f != NULL)
					svm_set_print_string_function(f);
				model = NULL;

				mapped_data = new MState[max_size];
				mapped_label = new int[max_size];
				mapped_path = new Path[max_size];
				data = new double*[max_size];
				label = new double[max_size];
				etimes = 0;
				for (int i = 0; i < max_size; i++)
					label[i] = -1;
				problem.l = 0;
				problem.x = (svm_node**)(data);
				problem.y = label;
				etimes = 1;
				kernel = 0;
				size = 0;

#ifdef __DS_ENABLED
				problem.np = 0;
				problem.nn = 0;
#endif
			}

			void setKernel(int kn) {
				kernel = kn;
			}

			~SVM() { 
				if (model != NULL) svm_free_and_destroy_model(&model);
#ifdef __PRT_DEBUG
				std::cout << "SVM deleted model\n";
#endif
				if (mapped_data != NULL) delete[] mapped_data;
#ifdef __PRT_DEBUG
				std::cout << "SVM deleted mapped_data\n";
#endif
				if (mapped_label != NULL) delete[] mapped_label;
#ifdef __PRT_DEBUG
				std::cout << "SVM deleted mapped_label\n";
#endif
				if (mapped_path!= NULL) delete[] mapped_path;
#ifdef __PRT_DEBUG
				std::cout << "SVM deleted mapped_path\n";
#endif
				if (data != NULL) delete[] data;
#ifdef __PRT_DEBUG
				std::cout << "SVM deleted data\n";
#endif
				if (label != NULL) delete[] label;
#ifdef __PRT_DEBUG
				std::cout << "SVM deleted label\n";
#endif
			}

			void mapData(States* gsets, int& pre_psize, int& pre_nsize) {
				//std::cout << "----->map data" << "\n";
				int cur_psize = gsets[POSITIVE].size;
				int cur_nsize = gsets[NEGATIVE].size;

#ifdef __PRT
				std::cout << GREEN << "  ++" << NORMAL << "[" << cur_psize - pre_psize << "+|"
					<< cur_nsize - pre_nsize  << "-]" << BLUE << " ==> " << NORMAL << "["
					<< cur_psize << "+|" << cur_nsize << "-]";
				std::cout << std::endl;
#endif

				dbg_print();
				int cur_index = pre_psize + pre_nsize;
				for (int i = 0; i < cur_psize - pre_psize; i++) {
					mappingData(gsets[POSITIVE].values[pre_psize + i], mapped_data[cur_index + i], 1);
					//mapped_label[cur_index + i] = gsets[POSITIVE].labels[pre_psize + i];
					mapped_label[cur_index + i] = 1;
					mapped_path[cur_index + i] = gsets[POSITIVE].paths[pre_psize + i];
				}
				dbg_print();
				cur_index = cur_psize + pre_nsize;
				for (int i = 0; i < cur_nsize - pre_nsize; i++) {
					mappingData(gsets[NEGATIVE].values[pre_nsize + i], mapped_data[cur_index + i], 1);
					mapped_label[cur_index + i] = -1;
					mapped_path[cur_index + i] = gsets[NEGATIVE].paths[pre_nsize + i];
				}
				dbg_print();
				pre_psize = cur_psize;
				pre_nsize = cur_nsize;
				size = cur_psize + cur_nsize;
				//std::cout << "<-----map data" << "\n";
			}

			int makeTrainingSet(Path* path_prefix) {
				//std::cout << "max-size=" << max_size << std::endl;
#ifdef __PRT_TRACE
				std::cout << "----->makeTrainingSet" << "\n";
#endif
				dbg_print();
				int index = 0;
				int cur_psize = 0, cur_nsize = 0;
				for (int i = 0; i < size; i++) {
					//if (mapped_label[i] == -1) {
					if ((mapped_label[i] == -1) && (mapped_path[i].matchPrefix(*path_prefix))) {
						data[index] = mapped_data[i];
						label[index++] = -1;
						cur_nsize++;
					} else if ((mapped_label[i] == 1) && (mapped_path[i].matchPrefix(*path_prefix))) {
						data[index] = mapped_data[i];
						label[index++] = 1;
						cur_psize++;
					}
				}

#ifdef __DS_ENABLED
				problem.np = cur_psize;
				problem.nn = cur_nsize;
#endif

				problem.l = cur_psize + cur_nsize;

				dbg_print();
				//std::cout << "makeTrainingSet => " << ret << "\n";

#ifdef __PRT_TRACE
				std::cout << GREEN << "problem----------------\n" << BLUE << problem << NORMAL << std::endl;
				std::cout << "<-----makeTrainingSet\n";
#endif

				//std::cout << GREEN << "problem----------------\n" << BLUE << problem << NORMAL << std::endl;
				return 0;
				}

				int train() {
					//std::cout << "training: +" << problem.np << "  -" << problem.nn << std::endl;
					if (problem.l == 0) {
						std::cout << "no data.\n";
						exit(-1);
					}
					/*
					if (problem.np == 0 || problem.nn == 0) {
						std::cout << "[ np=0 || nn=0 ]=> no data.\n";
						Polynomial poly;
						if (problem.nn == 0) {
							poly = true;
							cl = poly;
							return 0;
						} else if (problem.np == 0) {
							poly = false;
							cl = poly;
							return 0;
						}
					}
					*/
					//#ifdef __DS_ENABLED
					//#else
					//#endif
					if (problem.y == NULL || problem.x == NULL) return -1;
					//dbg_print();
					const char* error_msg = svm_check_parameter(&problem, &param);
					if (error_msg) { 
						std::cout << "ERROR: " << error_msg << std::endl; 
						return -1; 
					}

					//dbg_print();
					int res = 0;
					if (kernel == 0) {
						res = trainLinear();
					} else {
						res = trainPoly();
					}
					//dbg_print();

					return res;
				}


				double checkTrainingSet() {
					if (problem.l <= 0) return 0;
					int pass = 0;
#ifdef __PRT_POLYSVM
					std::cout << RED << BOLD << " PREDICT WRONGLY>>> >>" << NORMAL << BLUE;
#endif
					for (int i = 0; i < problem.l; i++) {
#ifdef __PRT_POLYSVM
						double predict_result = predict((double*)problem.x[i]);
						if (predict_result * problem.y[i] < 0) {
							std::cout << RED << BOLD << "([" << problem.x[i][0];
							for (int j = 1; j < Nv; j++)
								std::cout << "," << problem.x[i][j];
							std::cout << "]" << problem.y[i] << "->" << predict_result << ")  >>";
						}
#endif
						pass += (predict((double*)problem.x[i]) * problem.y[i] >= 0) ? 1 : 0;
					}
#ifdef __PRT_POLYSVM
					std::cout << RED << BOLD << " >>>>>END CHECKING\n" << NORMAL;
#endif
					return static_cast<double>(pass) / problem.l;
				}


				int checkQuestionTraces(States& qset) {
#ifdef __PRT
					std::cout << " [" << qset.traces_num() << "]";
#endif
					for (int i = 0; i < qset.p_index; i++) {
						int pre = -1, cur = 0;
#ifdef __PRT
						std::cout << ".";
#endif
						for (int j = qset.t_index[i]; j < qset.t_index[i + 1]; j++) {
							cur = predict(qset.values[j]);
							//std::cout << ((cur >= 0) ? "+" : "-");
							if ((pre >= 0) && (cur < 0)) {
								// deal with wrong question trace.
								// Trace back to print out the whole trace and the predicted labels.
#ifdef __PRT
								std::cerr << RED << "\t[FAIL]\n \t  Predict wrongly on Question traces.\n";
								qset.dumpTrace(i);
#endif
								for (int j = qset.t_index[i]; j < qset.t_index[i + 1]; j++) {
									cur = predict(qset.values[j]);
#ifdef __PRT
									std::cout << ((cur >= 0) ? "+" : "-");
#endif
								}
#ifdef __PRT
								std::cout << std::endl << NORMAL;
#endif
								return -1;
							}
							pre = cur;
						}
					}
#ifdef __PRT
					std::cout << " [PASS]";
#endif
					return 0;
				}

				bool converged (Classifier& pre_cl) {
					if (pre_cl.size <= 0) return false;
					return cl[0]->isSimilar(*pre_cl[0]);
				}


				friend std::ostream& operator << (std::ostream& out, const SVM& svm) {
					return svm._print(out);
				}

				std::ostream& _print(std::ostream& out) const {
					//svm_model_visualization(model, *classifier);
					//out << *poly; // << std::endl;
					//svm_model_visualization(model, poly);
					//out << cl << std::endl;
					out << cl[0]->toString(); // << std::endl;
					return out;
				}

				int getProblemSize() {
					return problem.l;
				}

				int predict(double* v) {
					if (model == NULL) return -2;
					if (v == NULL) return -2;
					double res = svm_predict(model, (svm_node*)v); 

					return res;
					if (res >= 0) return 1;
					else return -1;
				}

				int trainLinear() {
					Polynomial poly;
					//dbg_print();
					model = svm_train(&problem, &param);
					//dbg_print();
					//std::cout << *model << std::endl;
					svm_model_visualization(model, &poly);
					dbg_print();
					cl = poly;
					return 0;
				}

				int trainPoly() {
					Polynomial poly;
#ifdef __PRT_POLYSVM
					std::cout << RED  << "\ntrying from etimes = " << etimes << " $$$$$$ "<< NORMAL;
#endif
					while (etimes <= 4) {
						setEtimes(etimes);
						model = svm_train(&problem, &param);
						svm_model_visualization(model, &poly);
						double pass_rate = checkTrainingSet();
#ifdef __PRT_POLYSVM
						std::cout << BLUE << "   [" << etimes << "] " << pass_rate*100 << "% --> " << NORMAL << poly << std::endl;
#endif
						if (pass_rate == 1)
							break;
						etimes++;
					}
					if (etimes > 4) return -1;
					cl = poly;
					return 0;
				}
			};

#endif /* _SVM_H */
