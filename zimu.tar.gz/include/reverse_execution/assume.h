//#include <stdio.h>
#ifdef assume
#undef assume
#endif
//printf("------------------\n[depth=%d, SearchDepth=%d, Mask=%d]\n", depth, SearchDepth, Mask);
#if depth <= SearchDepth
	#if Mask>>depth & 1 == 1
		//printf("Choice 1: (%d <= %d), (%d >> %d & 1 == 1)::[klee_assume]->if\n", depth, SearchDepth, Mask, depth);
		#define assume(m) klee_assume(m); if(m)
	#else 
		//printf("Choice 2: (%d <= %d), (%d >> %d & 1 == 0)::[klee_assume(False)]->if\n", depth, SearchDepth, Mask, depth);
		#define assume(m) klee_assume(!(m)); if(m)
	#endif
#else
	//printf("Choice 3: (%d > %d), (%d >> %d & 1 == %d)::->pure-if\n", depth, SearchDepth, Mask, depth, Mask >> depth & 1);
	#define assume(m) if(m)
#endif
