#ifdef depth
#undef depth
#endif
