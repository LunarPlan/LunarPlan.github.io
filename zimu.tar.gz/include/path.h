/***************************************************************
 *  @file include/branch.h
 *  @brief           
 *             
 *  @author Li Jiaying
 *  @bug no known bugs
 ***************************************************************/
#ifndef _PATH_H_ 
#define _PATH_H_
#include "config.h"
#include "color.h"
#include "dbg.h"
#include <sstream>
#include <iostream>
#include <iomanip>
#include <bitset>

class Path{
	public:
		long u;
		int depth;
		std::string condition;

		Path() { 
			depth = 0; 
			u = 0;
		} 

		int operator[] (int d) const{
			if(d < 0 || d >= Mdepth) {
				std::cout << "Error [" << d << "]\n";
			}
			assert(d >= 0 && d < Mdepth);
			return u>>d & 1L;
		}

		bool isEmpty() {
			if (depth == 0)
				return true;
			return false;
		}

		inline bool set(int d) {
			assert(d < Mdepth);
			u |= 1L << d;
			depth = d > depth? d:depth;
			return true;
		}

		inline bool unset(int d) {
			assert(d < Mdepth);
			u &= (-1L) - (1L<<d);
			depth = d > depth? d:depth;
			return true;
			/*if (d > depth) return true;
			if ((*this)[d] == 1)
				u -= 1 << d;
				*/
		}

		/*bool& operator[] (int d){
			assert(d >= 0 && d < Mdepth);
			if (d >= depth)
				depth = depth + 1;
			return u[d];
		}*/

		Path& operator= (const Path& rhs) {
			u = rhs.u;
			depth = rhs.depth;
			return *this;
		}

		Path& operator= (const std::string str) {
			//std::cout << "----> assign PATH " << toString() << " with (string[" << str.length() << "])" << str << std::endl; 
			assert(str.length() <= Mdepth);
			depth = str.length() - 1;
			u = 0;
			for (int i = 1; i <= depth; i++) {
				if (str[i] == '1')
					set(i-1);
				if (str[i] == '0')
					unset(i-1);
			}
			//std::cout << "<---- assigned PATH " << toString() << std::endl; 
			return *this;
		}

		bool operator== (const Path& rhs) {
			if ((depth != rhs.depth) || (u != rhs.u))
				return false;
			return true;
		}

		bool matchPrefix(const Path& rhs) {
			if (rhs.depth == 0)
				return true;
			assert(rhs.depth < Mdepth);
			if (depth < rhs.depth) {
				//dbg_print();
				return false;
			}
			long mask = -1uL >> (Mdepth - rhs.depth);
			/*
			std::cout << " rhs.depth=" << rhs.depth << " mask=[" << std::bitset<32>(mask) << "]"; // << " {" << u & mask << ":" << rhs.u & mask<< "}"
			long umask = u & mask;
			long rhsumask = rhs.u & mask;
			std::cout << " u[" << std::bitset<32>(umask) << "]"<< " rhsu[" << std::bitset<32>(rhsumask) << "]"; // << " {" << u & mask << ":" << rhs.u & mask<< "}"
			*/
			return (u & mask) == (rhs.u & mask);
		}

		friend std::ostream& operator<< (std::ostream& out, const Path& p) {
			//out << "@";
			//for (int i = 0; i < p.depth; i++)
			//	out << "." << p[i];
			//out << "]";
			out << p.toString();
			return out;
		}

		std::string toString() const {
			std::ostringstream stm;
			stm << "*";
			for (int i = 0; i < depth; i++)
				stm << (*this)[i];
			return stm.str();
		}
		
		int toInt() const {
			if (depth == 0)
				return -1;
			int dec = 0;
			for (int i = 0; i < depth; i++)
				dec = dec * 10 + (*this)[i];
			return dec; 
		}
};


#endif
