#!/bin/bash
red="\e[31m"
green="\e[32m"
yellow="\e[33m"
blue="\e[34m"
normal="\e[0m"
bold="\e[1m"

times=1
TIMEOUT=60
precision2=("ex1" "popl" "popl_ex")
precision3=("cav" "ex2_1" "ex2_2")


if [ $# -ge 1 ]; then
	cfgfolder=$1
else
	cfgfolder="cfg"
fi

if [ $# -ge 2 ]; then
	times=$2
fi

if [ -d "./result" ]; then
	mv ./result ./result_old_`date +%m%d%H%M`
fi
mkdir -p result


nn=1
while [ $nn -le $times ]; do
	nn=$(($nn+1))
	from=`date +%m%d%H%M`
	i=1
	for cfgfile in `ls $cfgfolder/*.cfg`
	do
		file=`basename -s .cfg $cfgfile`
		PRECISION=1
		echo -e $yellow" $i) Processing benchmark {"$file"} ---------------------------------------------------------------------------------"$normal
		if echo "${precision2[@]}" | grep -w $file &>/dev/null; then
			#	echo "precision = 2 "
			PRECISION=2
		elif echo "${precision3[@]}" | grep -w $file &>/dev/null; then
			#	echo "precision = 3 "
			PRECISION=3
			#else
			#	echo "precision = 1 "
		fi

		CUT=0
		while [ $CUT -le 2 ]; do
			echo -e -n $red"                            |--> @cut"$CUT" ................................ "$normal
			{ time -p timeout $TIMEOUT ./run $cfgfile 0 $CUT; } > "result/"$file"_cut"$CUT".txt" 2>&1
			grep -nR "finish proving" result/$file"_cut"$CUT".txt" >/dev/null
			if [ $? -eq 0 ]; then
				echo -e $green"[pass]"$normal
			else
				echo -e $red"[fail]"$normal
			fi
			mv -f ./tmp/$file.inv ./result/$file"_cut"$CUT".inv"
			CUT=$(($CUT+1))
		done
		i=$(($i+1))
	done

	to=`date +%m%d%H%M`

	if [ -d "./result" ]; then
		mv ./result "./result_"$from"-"$to
	fi
done
exit 0
