#!/bin/bash
#dir_include=/home/parallels/Research/GitHub/ZILUv3/scripts
#dir_include=`dirname $(pwd)/${0}`
dir_include=$(cd $(dirname $BASH_SOURCE[0]) && pwd)
. $dir_include"/include.sh"

Nv=0

dir_org=`pwd`

prefix=$1
mkdir -p tmp
file_cfg=$prefix".cfg"
file_cpp=$prefix".cpp"
file_var=$prefix".var"
file_inv=$prefix".inv"
path_cfg=$dir_cfg"/"$file_cfg
path_cpp=$dir_test"/"$file_cpp
path_var=$dir_temp"/"$file_var
path_inv=$dir_temp"/"$file_inv
#prefix_path_inv=$dir_temp"/"$prefix



if [ $# -lt 1 ]; then
	echo "./build.sh needs more parameters"
	echo "./build.sh cofig_prefix"
	echo "try it again..."
	exit 1
fi
cd $dir_project

#**********************************************************************************************
# Learning phase
#**********************************************************************************************
##########################################################################
# Prepare the target loop program
##########################################################################
echo -n -e $blue"Converting the given config file to a valid cplusplus file..."$normal
cd $dir_parser
#make clean
mkdir -p build
cd build
cmake ..
make
mv parser ..
cd ..
#make clean
cd ..

#echo -e $green$bold$path_var$normal
cat $path_cfg | $dir_parser"/parser" -t 2 -o $path_cpp -v $path_var
read -r Nv < $path_var

#cat $path_cpp
sed -i 's/if/assume/g' $path_cpp
sed -i 's/@condition/if/g' $path_cpp
#cat $path_cpp

#////ERROR::::: sed -i "s/Depth[ \t]*([ \t]*\([0-9]+\)[ \t]*)[ \t]*\n/#include\ \"depth.h\"\n#define\ depth\ \1\n" $path_cpp
#sed -i 's/Depth[\ \t]*([\ \t]*\([1-9][0-9]*\)[\ \t]*);/\/\/Depth(\1)\n#include\ \"depth.h\"\n#define\ depth\ \1\n#include\ \"assume.h\"/g' $path_cpp

reverse_cpp=$dir_temp"/"$prefix"_reverse.cpp" 
#if [ ! -f $reverse_cpp ]; then 
cat "$dir_cfg/$prefix.cfg" | "$dir_parser/parser" -t 3 -o $reverse_cpp 
#fi
#cat $reverse_cpp

sed -i 's/if/assume/g' $reverse_cpp
 sed -i 's/Depth[\ \t]*([\ \t]*\([0-9]*\)[\ \t]*)[\ \t]*;/\/\/Depth(\1);\n#include\ "..\/include\/reverse_execution\/depth.h"\n#define\ depth\ \1\n#include\ "..\/include\/reverse_execution\/assume.h"/g' $reverse_cpp

echo -e $green$bold"[DONE]"$normal


##########################################################################
# Generate CMakeLists from cmake.base and Nv value
##########################################################################
echo -n -e $blue"Generating CMakeLists file for further construction..."$normal
cmakefile="$dir_project/CMakeLists.txt"
#cmakefile="./CMakeLists.txt"
echo "cmake_minimum_required (VERSION 2.8)" > $cmakefile
echo "set(Nv "$Nv")" >> $cmakefile
echo "set(Project "$prefix")" >> $cmakefile
echo "set(ProjectHome "$dir_project")" >> $cmakefile
		
if [ $# -ge 4 ]; then
	if [ $4 -eq 0 ]; then
		echo "add_definitions(-D__SELECTIVE_SAMPLING_ENABLED)" >> $cmakefile
	fi
fi

if [ $# -ge 5 ]; then
	echo -n -e $yellow"cut_method --> "$5":"
	if [ $5 -eq 0 ]; then
		echo -n -e " zero cut"
		echo "add_definitions(-D_ZERO_CUT_)" >> $cmakefile
	elif [ $5 -eq 1 ]; then
		echo -n -e " best cut"
		echo "add_definitions(-D_BEST_CUT_)" >> $cmakefile
	elif [ $5 -eq 2 ]; then
		echo -n -e " full cut"
		echo "add_definitions(-D_FULL_CUT_)" >> $cmakefile
	fi
	echo -e normal
fi

if [ $# -ge 6 ]; then
	#echo -e $yellow"Parameter6 --> "$6$normal
	if [ $6 -ge 1 ]; then
		echo "add_definitions(-D__QUESTION_AS_POSITIVE)" >> $cmakefile
	elif [ $6 -le -1 ]; then
		echo "add_definitions(-D__QUESTION_AS_NEGATIVE)" >> $cmakefile
	fi
fi

if [ $# -ge 7 ]; then
	#echo -e $yellow"Parameter7 --> "$6$normal
	echo "set(PRECISION "$7")" >> $cmakefile
else
	echo "set(PRECISION 1)" >> $cmakefile
fi
cat $dir_project"/cmake.in" >> $cmakefile
echo "add_executable("$prefix" "$path_cpp" \${DIR_SRCS} \${HEADER})" >> $cmakefile
echo "target_link_libraries("$prefix" \${Z3_LIBRARY})" >> $cmakefile
echo "target_link_libraries("$prefix" \${GSL_LIBRARIES})" >> $cmakefile
echo -e $green$bold"[DONE]"$normal
#cp $cmakefile $cmakefile".old"



##########################################################################
# Build the project
##########################################################################
echo -e $blue"Build the project..."$normal
cd $dir_build
#rm -rf *
cmake .. > /dev/null
make $prefix
if [ $? -ne 0 ]; then
	echo -e $red$bold"[FAIL]make error, contact developer to fix project source code first..."$normal
	cd ..
	exit 1
fi
cd $dir_project
rm $cmakefile
#echo -e $green$bold"[DONE]"$normal

cd $dir_org
exit 0
