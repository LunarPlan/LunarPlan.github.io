#!/bin/bash

#fullpath=$(pwd)/${0}
#dir=`dirname $fullpath`
dir=`dirname $(pwd)/${0}`
echo $dir
