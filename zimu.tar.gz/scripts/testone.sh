#!/bin/bash
red="\e[31m"
green="\e[32m"
yellow="\e[33m"
blue="\e[34m"
normal="\e[0m"
bold="\e[1m"

times=1
TIMEOUT=60
precision2=("ex1" "popl" "popl_ex")
precision3=("cav" "ex2_1" "ex2_2")


if [ $# -ge 1 ]; then
	cfgfile=$1
else
	cfgfile="cfg"
fi

if [ $# -ge 2 ]; then
	times=$2
fi

mkdir -p result

nn=1
while [ $nn -le $times ]; do
	nn=$(($nn+1))
	from=`date +%m%d%H%M`
	file=`basename -s .cfg $cfgfile`
	PRECISION=1
	if echo "${precision2[@]}" | grep -w $file &>/dev/null; then
		PRECISION=2
	elif echo "${precision3[@]}" | grep -w $file &>/dev/null; then
		PRECISION=3
	fi
	echo -e $yellow" $i) Processing benchmark {"$file"} ----------------------------precision=$PRECISION-----------------------------------------------------"$normal

	CUT=0
	while [ $CUT -le 2 ]; do
		echo -e -n $red"                            |--> @cut"$CUT" ................................ "$normal
		{ time -p timeout $TIMEOUT ./run $cfgfile 0 $CUT; } > "result/"$file"_cut"$CUT".txt" 2>&1
		grep -nR "finish proving" result/$file"_cut"$CUT".txt" >/dev/null
		if [ $? -eq 0 ]; then
			echo -e $green"[pass]"$normal
		else
			echo -e $red"[fail]"$normal
		fi
		mv -f ./tmp/$file.inv ./result/$file"_cut"$CUT".inv"
		CUT=$(($CUT+1))
	done
done
exit 0
