int main() {
	int n;
	int x;

	assume(n==0&&x==0);
	while(1) {
		n++; x+=2*n-1;
		assert(x==n*n);
	}
	return 0;
}