int main() {
	int x;
	int y;

	assume(x<=50 && y==50);
	while(x<100) {
		x++; ; if (x>50) y++;
	}
	assert(y==100);
	return 0;
}