int main() {
	int i;
	int n;
	int sn;

	assume(sn==0&&i==0);
	while(i<n) {
		i++; sn++;
	}
	assert(sn==n||sn==0);
	return 0;
}