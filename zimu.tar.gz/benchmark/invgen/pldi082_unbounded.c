int main() {
	int x;
	int y;
	int N;

	assume( x==y && x<=N && x>=0);
	while(y>=0) {
		; if (x<=N) y=y+1; else y=y-1; x=x+1; 
	}
	assert(x<2*N+4);
	return 0;
}