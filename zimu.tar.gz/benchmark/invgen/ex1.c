int main() {
	int x;
	int y;

	assume( x==y && x<=49 && x>=0);
	while(y>=0) {
		x=x+1; ; if (x<50) y=y+1; else y=y-1;
	}
	assert(x==99 && y==-1);
	return 0;
}