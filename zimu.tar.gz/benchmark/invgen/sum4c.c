int main() {
	int i;
	int sn;
	int size;

	assume(sn==0&&i==0);
	while(i<size) {
		i++; sn+=1;
	}
	assert(sn==size||sn==0);
	return 0;
}
