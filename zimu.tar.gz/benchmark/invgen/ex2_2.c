int main() {
	int x;
	int z;

	assume( x==z && x<25);
	while(x<100) {
		 ; if(x<25) z=z+1; else z=z+5; x=x+1;
	}
	assert( (x==100)&&(z==400));
	return 0;
}