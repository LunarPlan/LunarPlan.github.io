int main() {
	int i;
	int sn;
	int a;
	int size;

	assume(sn==0&&i==0);
	while(i<size) {
		i++; sn+=a;
	}
	assert(sn==size*a||sn==0);
	return 0;
}