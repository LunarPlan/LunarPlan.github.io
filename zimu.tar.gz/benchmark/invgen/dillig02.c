int main() {
	int x;
	int y;

	assume(x==y);
	while(1) {
		y++; ;if(y>x)x++;
		assert(x==y);
	}
	return 0;
}