int main() {
	int x;
	int y;
	int state;

	int flag;
	assume(x!=y&&state>=0);
	while(x!=y) {
		state=-1; x=y; ; if (flag) { state=1; y++; }
	}
	assert(state<0);
	return 0;
}