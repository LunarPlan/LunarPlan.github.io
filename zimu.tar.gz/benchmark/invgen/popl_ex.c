int main() {
	int x;
	int y;

	assume(x<=50 && y==50);
	while(x<100) {
		x++; ; if (x>50) {; if (y>70) y++; else y++;}
	}
	assert(y==100);
	return 0;
}