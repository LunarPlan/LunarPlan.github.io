int main() {
	int x;
	int y;
	int result;

	assume(x>=0&&result==x+y);
	while(x>0) {
		x--; y++;
	}
	assert(y==result);
	return 0;
}