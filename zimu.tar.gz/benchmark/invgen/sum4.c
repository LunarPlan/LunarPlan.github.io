int main() {
	int i;
	int sn;

	assume(sn==0&&i==0);
	while(i<8) {
		i++; sn+=1;
	}
	assert(sn==8||sn==0);
	return 0;
}