int main() {
	int x1;
	int x2;

	int b;
	assume(x1>=0&&x2>=0);
	while(x1>0&&x2>0) {
		;if(b) x1--; else x2--;
	}
	assert(x1==0||x2==0);
	return 0;
}