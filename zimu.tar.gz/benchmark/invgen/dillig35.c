int main() {
	int x;
	int n;

	assume(x==0);
	while(x<n) {
		x++;
	}
	assert(n<=0||x==n);
	return 0;
}