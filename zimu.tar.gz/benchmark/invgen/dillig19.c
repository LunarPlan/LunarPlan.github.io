int main() {
	int x;
	int y;
	int m;
	int n;

	assume(m>=0&&m<n&&x<=m&&y==m);
	while(x<n) {
		x++; ; if(x>m) y++;
	}
	assert(y==n);
	return 0;
}