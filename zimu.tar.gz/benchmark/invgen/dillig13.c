int main() {
	int j;
	int k;
	int flag;

	assume(j==2&&k==0);
	while(1) {
		if(flag>0) j=j+4; else { j=j+2; k=k+1; }
		assert(k==0||j==2*k+2);
	}
	return 0;
}
