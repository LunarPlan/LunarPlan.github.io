int main() {
	int x1;
	int x2;
	int x3;

	int b1, b2;
	assume(x1>=0&&x2>=0&&x3>=0);
	while(x1>0&&x2>0&&x3>0) {
		if(b1) x1--; else {if (b2) x2--; else x3--; }
	}
	assert(x1==0||x2==0||x3==0);
	return 0;
}
