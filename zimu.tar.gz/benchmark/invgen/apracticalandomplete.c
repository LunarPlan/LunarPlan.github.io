int main() {
	int x;
	int y;
	int i;
	int j;

	assume( x==i && y==j && j>0 && i>0);
	while(y>0) {
		x--; y--;
	}
	assert(i!=j || x<=0);
	return 0;
}