int main() {
	int x;
	int y;

	int flag1, flag2;
	assume( x==y && x==0);
	while(1) {
		if(flag1) {x++; y=y+2;} else { if (flag2 && x>=4) {x++; y=y+3;} }
		assert(3*x>=y);
	}
	return 0;
}
