int main() {
	int x;
	int y;

	assume( x==y && x<51 && x>=0);
	while(y>=0) {
		; if (x<=50) y=y+1; else y=y-1; ; if (y>=0) x=x+1;
	}
	assert(x<=102 && y<=51);
	return 0;
}