int main() {
	int x;
	int y;

	assume( x==y && x<25);
	while(x<100) {
		 ; if(x<=50) y=y+1; else y=y-1; x=x+1;
	}
	assert( (x==100)&&(y==2));
	return 0;
}