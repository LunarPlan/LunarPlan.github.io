int main() {
	int i;
	int j;
	int n;

	int flag;
	assume(i==j);
	while(1) {
		n++; i+=n; j+=n; ; if (flag) j+=1;
		assert(j>=i);
	}
	return 0;
}