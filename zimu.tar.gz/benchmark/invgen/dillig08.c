int main() {
	int x;
	int y;

	int flag1, flag2;
	assume(x==y);
	while(1) {
		if (flag1) {x++; y+=100;} else { if (flag2) { if (x>=4) {x++; y++;} }}
		assert(x<4||y>2);
	}
	return 0;
}
