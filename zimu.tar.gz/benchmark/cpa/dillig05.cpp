extern void __assert_fail();

#define Depth(n) do{;} while(0)
int main() {
	int i;
	int j;
	int n;

	int flag;
	if(!(i==j)) {
		 return 0;
	}
	while(1) {
	n++; i+=n; j+=n; Depth(1); if (flag) j+=1;
		if(!(j>=i)) {
			 goto ERROR;
		}
	}
	return 0;

ERROR: 
	__assert_fail();
	return 1;
}