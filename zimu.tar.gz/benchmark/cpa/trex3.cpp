extern void __assert_fail();

#define Depth(n) do{;} while(0)
int main() {
	int x1;
	int x2;
	int x3;

	int b1, b2;
	if(!(x1>=0&&x2>=0&&x3>=0)) {
		 return 0;
	}
	while(x1>0&&x2>0&&x3>0) {
	Depth(1);if(b1) x1--; else {Depth(2); if (b2) x2--; else x3--; }
	}
	if(!(x1==0||x2==0||x3==0)) {
		 goto ERROR;
	}
	return 0;

ERROR: 
	__assert_fail();
	return 1;
}
