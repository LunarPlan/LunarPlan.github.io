extern void __assert_fail();

#define Depth(n) do{;} while(0)
int main() {
	int x;
	int y;

	int flag1, flag2;
	if(!(x==y)) {
		 return 0;
	}
	while(1) {
	Depth(1); if (flag1) {x++; y+=100;} else { Depth(2); if (flag2 && x>=4) {x++; y++;} }
		if(!(x<4||y>2)) {
			 goto ERROR;
		}
	}
	return 0;

ERROR: 
	__assert_fail();
	return 1;
}
