extern void __assert_fail();

#define Depth(n) do{;} while(0)
int main() {
	int i;
	int sn;
	int size;

	if(!(sn==0&&i==0)) {
		 return 0;
	}
	while(i<size) {
	i++; sn+=1;
	}
	if(!(sn==size||sn==0)) {
		 goto ERROR;
	}
	return 0;

ERROR: 
	__assert_fail();
	return 1;
}
