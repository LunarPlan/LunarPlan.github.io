extern void __assert_fail();

#define Depth(n) do{;} while(0)
int main() {
	int x1;
	int x2;

	int b;
	if(!(x1>=0&&x2>=0)) {
		 return 0;
	}
	while(x1>0&&x2>0) {
	Depth(1);if(b) x1--; else x2--;
	}
	if(!(x1==0||x2==0)) {
		 goto ERROR;
	}
	return 0;

ERROR: 
	__assert_fail();
	return 1;
}