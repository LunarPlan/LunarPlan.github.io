extern void __assert_fail();

#define Depth(n) do{;} while(0)
int main() {
	int x;
	int y;
	int result;

	if(!(x>=0&&result==x+y)) {
		 return 0;
	}
	while(x>0) {
	x--; y++;
	}
	if(!(y==result)) {
		 goto ERROR;
	}
	return 0;

ERROR: 
	__assert_fail();
	return 1;
}