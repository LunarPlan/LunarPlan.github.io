#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int n = _reserved_input_[1];
	if(a==0&&n>=0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int a = _reserved_input_[0];
	int n = _reserved_input_[1];
	if(a==0&&n>=0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int n = _reserved_input_[1];
	if(a*a<=n && (a+1)*(a+1)>n)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int a = _reserved_input_[0];
	int n = _reserved_input_[1];
	if(a*a<=n && (a+1)*(a+1)>n)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int n = _reserved_input_[1];

	int t = 1; int su = 1;
	precondition(a==0&&n>=0);

	while(su<=n) {
		record_variable_int(a, n);
		Depth(0);
		record_path(depth, 1);
		a++;
		t=t+2;
		su = su + t;
		
	}
	record_variable_int(a, n);
	Depth(0);
	record_path(depth, 0);

	postcondition(a*a<=n && (a+1)*(a+1)>n);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

