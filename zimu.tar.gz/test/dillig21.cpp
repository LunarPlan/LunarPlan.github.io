#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int k = _reserved_input_[1];
	int n = _reserved_input_[2];
	if(i==0&&k==0&&n>0&&n<10)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int i = _reserved_input_[0];
	int k = _reserved_input_[1];
	int n = _reserved_input_[2];
	if(i==0&&k==0&&n>0&&n<10)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int k = _reserved_input_[1];
	int n = _reserved_input_[2];
	if(k>n)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int i = _reserved_input_[0];
	int k = _reserved_input_[1];
	int n = _reserved_input_[2];
	if(k>n)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int k = _reserved_input_[1];
	int n = _reserved_input_[2];

	precondition(i==0&&k==0&&n>0&&n<10);

	while(i<n) {
		record_variable_int(i, k, n);
		Depth(0);
		record_path(depth, 1);
			int flag = rand() % 2;
		i++;
		Depth(1);
		assume(flag) k+=40;
		else k+=20;
		
	}
	record_variable_int(i, k, n);
	Depth(0);
	record_path(depth, 0);

	postcondition(k>n);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

