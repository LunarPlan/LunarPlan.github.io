#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	if( x==y && x==0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	if( x==y && x==0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	if(3*x>=y)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	if(3*x>=y)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];

	precondition( x==y && x==0);

	while(rand()%4) {
		record_variable_int(x, y);
		Depth(0);
		record_path(depth, 1);
			int flag1 = rand() % 2;
			int flag2 = rand() % 2;
		Depth(1);
		assume(flag1) {
		x++;
		y=y+2;
		}
		else {
		Depth(2);
		assume (flag2 && x>=4) {
		x++;
		y=y+3;
		}
		}
		
	}
	record_variable_int(x, y);
	Depth(0);
	record_path(depth, 0);

	postcondition(3*x>=y);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

