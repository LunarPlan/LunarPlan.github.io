#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int j = _reserved_input_[0];
	int k = _reserved_input_[1];
	int flag = _reserved_input_[2];
	if(j==2&&k==0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int j = _reserved_input_[0];
	int k = _reserved_input_[1];
	int flag = _reserved_input_[2];
	if(j==2&&k==0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int j = _reserved_input_[0];
	int k = _reserved_input_[1];
	int flag = _reserved_input_[2];
	if(k==0||j==2*k+2)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int j = _reserved_input_[0];
	int k = _reserved_input_[1];
	int flag = _reserved_input_[2];
	if(k==0||j==2*k+2)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int j = _reserved_input_[0];
	int k = _reserved_input_[1];
	int flag = _reserved_input_[2];

	precondition(j==2&&k==0);

	while(rand()%4) {
		record_variable_int(j, k, flag);
		Depth(0);
		record_path(depth, 1);
		Depth(1);
		assume(flag>0) j=j+4;
		else {
		j=j+2;
		k=k+1;
		}
		
	}
	record_variable_int(j, k, flag);
	Depth(0);
	record_path(depth, 0);

	postcondition(k==0||j==2*k+2);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

