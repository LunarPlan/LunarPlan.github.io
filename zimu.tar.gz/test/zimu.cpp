#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int N = _reserved_input_[2];
	if( x==y && x<=N && N>=0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int N = _reserved_input_[2];
	if( x==y && x<=N && N>=0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int N = _reserved_input_[2];
	if(x<2*N+4)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int N = _reserved_input_[2];
	if(x<2*N+4)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int N = _reserved_input_[2];

	precondition( x==y && x<=N && N>=0);

	while(y>=0) {
		record_variable_int(x, y, N);
		Depth(0);
		record_path(depth, 1);
		Depth(1);
		assume (x<=N) y=y+1;
		else y=y-1;
		x=x+1;
		
	}
	record_variable_int(x, y, N);
	Depth(0);
	record_path(depth, 0);

	postcondition(x<2*N+4);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

