#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	int x3 = _reserved_input_[2];
	if(x1>=0&&x2>=0&&x3>=0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	int x3 = _reserved_input_[2];
	if(x1>=0&&x2>=0&&x3>=0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	int x3 = _reserved_input_[2];
	if(x1==0||x2==0||x3==0)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	int x3 = _reserved_input_[2];
	if(x1==0||x2==0||x3==0)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	int x3 = _reserved_input_[2];

	precondition(x1>=0&&x2>=0&&x3>=0);

	while(x1>0&&x2>0&&x3>0) {
		record_variable_int(x1, x2, x3);
		Depth(0);
		record_path(depth, 1);
			int b1 = rand() % 2;
			int b2 = rand() % 2;
		Depth(1);
		assume(b1) x1--;
		else {
		Depth(2);
		assume (b2) x2--;
		else x3--;
		}
		
	}
	record_variable_int(x1, x2, x3);
	Depth(0);
	record_path(depth, 0);

	postcondition(x1==0||x2==0||x3==0);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

