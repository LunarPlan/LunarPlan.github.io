#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	if(x1>=0&&x2>=0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	if(x1>=0&&x2>=0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	if(x1==0||x2==0)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];
	if(x1==0||x2==0)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int x1 = _reserved_input_[0];
	int x2 = _reserved_input_[1];

	precondition(x1>=0&&x2>=0);

	while(x1>0&&x2>0) {
		record_variable_int(x1, x2);
		Depth(0);
		record_path(depth, 1);
			int b = rand() % 2;
		Depth(1);
		assume(b) x1--;
		else x2--;
		
	}
	record_variable_int(x1, x2);
	Depth(0);
	record_path(depth, 0);

	postcondition(x1==0||x2==0);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

