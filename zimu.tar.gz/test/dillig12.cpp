#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int s = _reserved_input_[2];
	int t = _reserved_input_[3];
	if(a==b&&a>=0&&s==0&&t==0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int s = _reserved_input_[2];
	int t = _reserved_input_[3];
	if(a==b&&a>=0&&s==0&&t==0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int s = _reserved_input_[2];
	int t = _reserved_input_[3];
	if(2*s>=t)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int s = _reserved_input_[2];
	int t = _reserved_input_[3];
	if(2*s>=t)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int s = _reserved_input_[2];
	int t = _reserved_input_[3];

	precondition(a==b&&a>=0&&s==0&&t==0);

	while(rand()%4) {
		record_variable_int(a, b, s, t);
		Depth(0);
		record_path(depth, 1);
			int flag = rand() % 2;
		a++;
		b++;
		s+=a;
		t+=b;
		Depth(1);
		assume(flag) t+=a;
		
	}
	record_variable_int(a, b, s, t);
	Depth(0);
	record_path(depth, 0);

	postcondition(2*s>=t);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

