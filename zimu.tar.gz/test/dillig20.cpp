#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int i = _reserved_input_[2];
	int j = _reserved_input_[3];
	int k = _reserved_input_[4];
	int m = _reserved_input_[5];
	int n = _reserved_input_[6];
	if(x+y==k&&n>0&&j==0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int i = _reserved_input_[2];
	int j = _reserved_input_[3];
	int k = _reserved_input_[4];
	int m = _reserved_input_[5];
	int n = _reserved_input_[6];
	if(x+y==k&&n>0&&j==0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int i = _reserved_input_[2];
	int j = _reserved_input_[3];
	int k = _reserved_input_[4];
	int m = _reserved_input_[5];
	int n = _reserved_input_[6];
	if((x+y)==k&&m>=0&&m<n)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int i = _reserved_input_[2];
	int j = _reserved_input_[3];
	int k = _reserved_input_[4];
	int m = _reserved_input_[5];
	int n = _reserved_input_[6];
	if((x+y)==k&&m>=0&&m<n)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int x = _reserved_input_[0];
	int y = _reserved_input_[1];
	int i = _reserved_input_[2];
	int j = _reserved_input_[3];
	int k = _reserved_input_[4];
	int m = _reserved_input_[5];
	int n = _reserved_input_[6];

	precondition(x+y==k&&n>0&&j==0);

	while(j<n) {
		record_variable_int(x, y, i, j, k, m, n);
		Depth(0);
		record_path(depth, 1);
			int flag = rand() % 2;
		Depth(1);
		assume(i==j) {
		x++;
		y--;
		}
		else {
		y++;
		x--;
		}
		Depth(2);
		assume(flag) m=j;
		j++;
		
	}
	record_variable_int(x, y, i, j, k, m, n);
	Depth(0);
	record_path(depth, 0);

	postcondition((x+y)==k&&m>=0&&m<n);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

