#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int k = _reserved_input_[2];
	int n = _reserved_input_[3];
	int b = _reserved_input_[4];
	if(i==j&&n==0&&b!=0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int k = _reserved_input_[2];
	int n = _reserved_input_[3];
	int b = _reserved_input_[4];
	if(i==j&&n==0&&b!=0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int k = _reserved_input_[2];
	int n = _reserved_input_[3];
	int b = _reserved_input_[4];
	if(i==j)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int k = _reserved_input_[2];
	int n = _reserved_input_[3];
	int b = _reserved_input_[4];
	if(i==j)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int k = _reserved_input_[2];
	int n = _reserved_input_[3];
	int b = _reserved_input_[4];

	precondition(i==j&&n==0&&b!=0);

	while(n<2*k) {
		record_variable_int(i, j, k, n, b);
		Depth(0);
		record_path(depth, 1);
		n++;
		Depth(1);
		assume (b>0) i++;
		else j++;
		b = -b;
		
	}
	record_variable_int(i, j, k, n, b);
	Depth(0);
	record_path(depth, 0);

	postcondition(i==j);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

