#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int x = _reserved_input_[2];
	int y = _reserved_input_[3];
	if(i==j && x==y)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int x = _reserved_input_[2];
	int y = _reserved_input_[3];
	if(i==j && x==y)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int x = _reserved_input_[2];
	int y = _reserved_input_[3];
	if(j>=i)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int x = _reserved_input_[2];
	int y = _reserved_input_[3];
	if(j>=i)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int i = _reserved_input_[0];
	int j = _reserved_input_[1];
	int x = _reserved_input_[2];
	int y = _reserved_input_[3];

	precondition(i==j && x==y);

	while(rand()%4) {
		record_variable_int(i, j, x, y);
		Depth(0);
		record_path(depth, 1);
			int flag = rand() % 2;
		x++;
		y++;
		i+=x;
		j+=y;
		Depth(1);
		assume (flag) j+=1;
		
	}
	record_variable_int(i, j, x, y);
	Depth(0);
	record_path(depth, 0);

	postcondition(j>=i);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

