#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int xa = _reserved_input_[0];
	int ya = _reserved_input_[1];
	if( xa==0 && ya==0)
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int xa = _reserved_input_[0];
	int ya = _reserved_input_[1];
	if( xa==0 && ya==0)
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int xa = _reserved_input_[0];
	int ya = _reserved_input_[1];
	if(xa+2*ya>=0)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int xa = _reserved_input_[0];
	int ya = _reserved_input_[1];
	if(xa+2*ya>=0)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int xa = _reserved_input_[0];
	int ya = _reserved_input_[1];

	precondition( xa==0 && ya==0);

	while(rand()%4) {
		record_variable_int(xa, ya);
		Depth(0);
		record_path(depth, 1);
			int flag = rand() % 2;
		int x=xa+2*ya;
		int y=-2*xa+ya;
		x++;
		Depth(1);
		assume (flag) y=y+x;
		else y=y-x;
		xa=x-2*y;
		ya=2*x+y;
		
	}
	record_variable_int(xa, ya);
	Depth(0);
	record_path(depth, 0);

	postcondition(xa+2*ya>=0);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

