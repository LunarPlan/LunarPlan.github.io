#include "assume.h"
#include "record.h"
#include <iostream>
using namespace std;
using namespace record;
int depth;


bool check_precondition(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int i = _reserved_input_[2];
	if((a == 0) && (b == 0) && (i==0))
		return true;
	return false;
}


bool check_precondition(double _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int i = _reserved_input_[2];
	if((a == 0) && (b == 0) && (i==0))
		return true;
	return false;
}


bool check_postcondition(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int i = _reserved_input_[2];
	if(a + b == 3 * i)
		return true;
	return false;
}


bool check_postcondition(double _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int i = _reserved_input_[2];
	if(a + b == 3 * i)
		return true;
	return false;
}

int loopFunction(int _reserved_input_[]) {
	int a = _reserved_input_[0];
	int b = _reserved_input_[1];
	int i = _reserved_input_[2];

	precondition((a == 0) && (b == 0) && (i==0));

	while(rand()%4) {
		record_variable_int(a, b, i);
		Depth(0);
		record_path(depth, 1);
			int cond = rand() % 2;
		Depth(1);
		assume (cond) {
		a = a + 1;
		b = b + 2;
		}
		else {
		a = a + 2;
		b = b + 1;
		}
		i = i + 1;
		
	}
	record_variable_int(a, b, i);
	Depth(0);
	record_path(depth, 0);

	postcondition(a + b == 3 * i);

	return 0;
}

int main(int argc, char** argv) {
	Context context(argv[1], argv[2], loopFunction, "loopFunction", NULL);
	context.addLearner("conjunctive");
	return context.learn(argv[3], argv[4]);
}

